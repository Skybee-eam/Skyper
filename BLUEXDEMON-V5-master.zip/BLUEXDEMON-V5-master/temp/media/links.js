exports.vnMenu = [
"https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/audio1.mp3",
"https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/audio1.mp3",
"https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/audio1.mp3"
]
exports.images = [
        'https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/menu1.jpg',
        'https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/menu2.jpg',
        'https://huggingface.co/spaces/API-X/BOT-BASE/resolve/main/menu3.jpg'
    ];
exports.zoroImages = [
        'https://wallpapercave.com/wp/wp13833689.jpg',
        'https://wallpapercave.com/wp/wp12456894.jpg',
        'https://wallpapercave.com/wp/wp13337959.jpg',
        'https://wallpapercave.com/wp/wp11267746.jpg',
        'https://wallpapercave.com/wp/wp13833690.jpg'
    ];