const pairNumber = "234xxxxxxxxxxx";

const accNumber = ""

const name = ""

const bankName = ""

const any = "𓃵"

module.exports = { pairNumber, accNumber, bankName, name, any };
